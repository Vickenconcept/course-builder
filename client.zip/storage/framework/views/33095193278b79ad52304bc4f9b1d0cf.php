<button <?php echo e($attributes->merge(['type' => 'button', 'class' => ' items-center  text-blue-50 px-3 border border-yellow-500 text-center  rounded bg-yellow-500 hover:shadow-lg transition duration-300 py-2 text-xs font-semibold   disabled:opacity-25  ease-in-out'])); ?>>
    <?php echo e($slot); ?>

</button>

<?php /**PATH C:\wamp64\www\AI-Course-shop-master\resources\views/components/main-button.blade.php ENDPATH**/ ?>