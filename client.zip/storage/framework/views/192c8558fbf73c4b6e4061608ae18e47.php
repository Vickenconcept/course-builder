<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.notification','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('notification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <div class="grid  grid-cols-1 md:grid-cols-3 gap-5 px-5" x-data="{ openMailChimp: false, paypal: false }">
        <div class="col-span-1 grid gap-5">
            <!-- component -->
            <div class="bg-gray-200 min-h-screen pt-2 font-mono mb-16">
                <div class="container mx-auto">
                    <div class="inputs w-full max-w-2xl p-6 mx-auto">
                        <h2 class="text-2xl text-gray-900"><i class='bx bxs-cog text-4xl'></i>Account Setting</h2>
                        <div class="mt-6 border-t border-gray-400 pt-4">
                            <div class='flex flex-wrap -mx-3 mb-6'>

                                
                                
                                

                                
                                <div x-data="{ isOpen: true }" class=" my-5 bg-white w-full rounded">
                                    <button @click="isOpen = !isOpen"
                                        class="bg-transparent border-none text-gray-700 py-2 px-4 cursor-pointer font-bold underline"><i
                                            class='bx bxs-envelope mr-1'></i>ESP </button>
                                    <div x-show="isOpen" class="p-4 w-full">
                                        <ul class="list-none p-0 text-gray-700 w-full">
                                            <a href="#"
                                                class=" underline hover:bg-yellow-500 hover:text-white w-full block rounded translate duration-300 p-3"
                                                class="" @click="openMailChimp = !openMailChimp"><i class='bx bxl-mailchimp text-xl'></i>MailChimp</a>
                                            <a href="#"
                                                class=" underline hover:bg-yellow-500 hover:text-white w-full block rounded translate duration-300 p-3"
                                                @click="paypal = !paypal"><i class='bx bxl-paypal text-xl'></i>Paypal</a>
                                        </ul>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
        </div>

        <div class="col-span-2">
            <!-- component -->
            <div class="bg-gray-200 min-h-screen pt-2 font-mono mb-16">
                <div class="container mx-auto">
                    <div class="inputs w-full max-w-2xl p-6 mx-auto">
                        <h2 class="text-2xl text-gray-900">Account Setting</h2>
                        <div class="mt-6 border-t border-gray-400 pt-4">
                            
                            <div x-show="openMailChimp" class="mb-6">
                                <h1 class="text-2xl text-gray-900 my-4">Mailchimp Credentials</h1>
                                <form action="<?php echo e(route('setting.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                                        <div class='w-full md:w-full inline  mb-6'>
                                            <label
                                                class='block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2'
                                                for='grid-text-1'>API Key </label>
                                            <input
                                                class='appearance-none block w-full bg-white text-gray-700 border border-gray-400 shadow-inner rounded-md py-2 px-4 leading-tight focus:outline-none  focus:border-gray-500'
                                                id='grid-text-1' type='text' placeholder='Enter API key'
                                                name="mailchimp_api_key"
                                                value="<?php echo e(auth()->user()->setting->mailchimp_api_key ?? ''); ?>">
                                        </div>
                                        <div class='w-full md:w-full inline px-3 mb-6'>
                                            <label
                                                class='block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2'
                                                for='grid-text-1'>Prefix</label>
                                            <input
                                                class='appearance-none block w-full bg-white text-gray-700 border border-gray-400 shadow-inner rounded-md py-2 px-4 leading-tight focus:outline-none  focus:border-gray-500'
                                                id='grid-text-1' type='text' placeholder='Enter prefix eg. us21'
                                                name="mailchimp_prefix_key"
                                                value="<?php echo e(auth()->user()->setting->mailchimp_prefix_key ?? ''); ?>">
                                        </div>
                                    </div>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>submit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                                </form>
                            </div>
                            



                            <div class='flex flex-wrap -mx-3 my-6  border-t border-b border-gray-400'>
                                
                                
                                
                                
                                <div class="personal w-full pt-4 ">
                                    <h2 class="text-2xl text-gray-900">Personal info:</h2>
                                    <div class="flex items-center justify-between mt-4">
                                        <div class='w-full md:w-1/2 px-3 mb-6'>
                                            <label
                                                class='block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2'>
                                                Name</label>
                                            <input
                                                class='appearance-none block w-full bg-gray-100 text-gray-700 border border-gray-400 shadow-inner rounded-md py-2 px-4 leading-tight focus:outline-none  focus:border-gray-500'
                                                type='text' value="<?php echo e(auth()->user()->name); ?>" disabled>
                                        </div>
                                        <div class='w-full md:w-1/2 px-3 mb-6'>
                                            <label
                                                class='block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2'>
                                                Email Address</label>
                                            <input
                                                class='appearance-none block w-full bg-gray-100 text-gray-700 border border-gray-400 shadow-inner rounded-md py-2 px-4 leading-tight focus:outline-none  focus:border-gray-500'
                                                type='text' value="<?php echo e(auth()->user()->email); ?>" disabled>
                                        </div>
                                    </div>
                                    
                                    
                                    
                                </div>
                            </div>

                            
                            <div x-show="paypal" class="mt-5">
                                <h1 class="text-2xl text-gray-900 my-4">Paypal credentials </h1>
                                <form action="<?php echo e(route('setting.paypalData')); ?>" method="POST">
                                    
                                    <?php echo csrf_field(); ?>
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                                        <div class='w-full md:w-full inline  mb-6'>
                                            <label
                                                class='block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2'
                                                for='grid-text-1'>API_USERNAME</label>
                                            <input
                                                class='appearance-none block w-full bg-white text-gray-700 border border-gray-400 shadow-inner rounded-md py-2 px-4 leading-tight focus:outline-none  focus:border-gray-500'
                                                id='grid-text-1' type='text' placeholder='Enter API username'
                                                name="paypal_api_username"
                                                value="<?php echo e(auth()->user()->setting->paypal_api_username ?? ''); ?>">
                                        </div>
                                        <div class='w-full md:w-full inline px-3 mb-6'>
                                            <label
                                                class='block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2'
                                                for='grid-text-1'>API_PASSWORD</label>
                                            <input
                                                class='appearance-none block w-full bg-white text-gray-700 border border-gray-400 shadow-inner rounded-md py-2 px-4 leading-tight focus:outline-none  focus:border-gray-500'
                                                id='grid-text-1' type='text' placeholder='Enter password'
                                                name="paypal_api_password"
                                                value="<?php echo e(auth()->user()->setting->paypal_api_password ?? ''); ?>">
                                        </div>
                                        <div class='w-full md:w-full inline px-3 mb-6'>
                                            <label
                                                class='block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2'
                                                for='grid-text-1'>API_SECRET</label>
                                            <input
                                                class='appearance-none block w-full bg-white text-gray-700 border border-gray-400 shadow-inner rounded-md py-2 px-4 leading-tight focus:outline-none  focus:border-gray-500'
                                                id='grid-text-1' type='text' placeholder='Enter secret'
                                                name="paypal_api_secret"
                                                value="<?php echo e(auth()->user()->setting->paypal_api_secret ?? ''); ?>">
                                        </div>
                                    </div>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>submit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                                </form> 
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\AI-Course-shop-master\resources\views/users/setting.blade.php ENDPATH**/ ?>