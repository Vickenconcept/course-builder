<div wire:poll.visible="updateDatabase" wire:poll.10s class="bg-white" x-data="{ ignore: true }">



    <div wire:ignore>
        <textarea id="content-<?php echo e($lesson->id); ?>" name="content" class="w-full" rows="10" input="content" wire:model="content"><?php echo e($content); ?></textarea>
    </div>

    <script>
      
        jQuery.noConflict();
        (function($) {
            // Your jQuery code here
            jQuery(document).ready(function() {
                // Your Summernote initialization code here
                $('#content-<?php echo e($lesson->id); ?>').summernote({
                    height: 300,
                    minHeight: null,
                    maxHeight: null,
                    focus: true,
                    callbacks: {
                        onChange: function(contents, $editable) {
                            window.livewire.find('<?php echo e($_instance->id); ?>').set('content', contents);
                        },
                    }
                });


            });


            document.addEventListener("livewire:load", function() {
                window.livewire.on('addToTextarea', function(data, lessonId) {
                    // Get the Summernote editor instance using the lessonId
                    var summernote = $('#content-' + lessonId);
                    // Set the received data as the Summernote editor's content
                    summernote.summernote('code', data);
                });
            });
        })(jQuery);


    </script>

</div>
<?php /**PATH C:\wamp64\www\AI-Course-shop-master\resources\views/livewire/text-editor.blade.php ENDPATH**/ ?>