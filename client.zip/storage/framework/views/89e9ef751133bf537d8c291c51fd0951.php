<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="grid grid-cols-1 md:grid-cols-3  gap-8 p-2 md:px-10 text-gray-700" x-data="{ isOpen: false, isOpen2: false }">
        <div class="w-full" x-data="{ research: '' }">
            <h1 class=" capitalize text-md font-semibold mt-5"><i class="bx bx-book ml-1"></i> My saved Courses</h1>
            <section class="">
                <?php if(isset($researches)): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $researches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $research): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="bg-white shadow-md border-b relative rounded p-3 my-4  transition duration-300 ease-in-out cursor-pointer"
                            @click=" isOpen2= true; research = <?php echo \Illuminate\Support\Js::from($research)->toHtml() ?>">
                            <div class="flex justify-between">
                                <span
                                    class="text-gray-300 text-xs"><?php echo e($research->created_at->toFormattedDayDateString()); ?></span>
                                <div class="text-xs ">
                                    <form :id="research.id"
                                        action="<?php echo e(route('course-validation.destroy', ['course_validation' => $research->id])); ?>"
                                        method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="font-bold text-xs">Delete</button>
                                    </form>
                                </div>
                            </div>

                            <div class="">
                                <h2 class="mb-3 font-bold text-sm text-gray-500"> <?php echo e($research->title); ?></h2>
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <p class="truncate text-gray-500 text-sm"><?php echo e($research->description); ?></p>
                                        <p class=" text-gray-500 text-sm"><?php echo e($research->author); ?></p>
                                    </div>

                                </div>
                            </div>

                        </div>

                        
                        <div x-show="isOpen2"
                            class="fixed z-[60] inset-0 overflow-y-auto bg-gray-500/50 transform  transition-all  duration-700 -full"
                            style="display: none;">
                            <div class="flex items-center justify-center min-h-screen px-10">
                                <div class="bg-white w-[90%] rounded overflow-hidden pb-6 transition-all relative duration-700"
                                   >
                                    <div>
                                        <button type="button" class=" px-4 pt-3" @click="isOpen2 = false">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                    d="M6 18L18 6M6 6l12 12" />
                                            </svg>

                                        </button>
                                    </div>
                                    <div class="p-5 overflow-y-auto">
                                        <div class="h-96">
                                            </h2>
                                            <a :href="research.infolink" target="_blank">
                                                <h3 class="my-3 underline text-2xl font-bold" x-text="research.title">
                                                </h3>
                                            </a>

                                            <p x-text="research.description"
                                                class="text-gray-400 text-sm truncate w-[80%]"></p>
                                            <div class="grid grid-cols-1 md:grid-cols-3 gap-5 py-10">
                                                <div>
                                                    <h4 class="font-semibold mb-3">Details</h4>
                                                    <p class=" text-gray-700 my-2"> Instructor: <span class="ml-5 "
                                                            x-text="research.author"></span></p>
                                                    <p class=" text-gray-700 my-2"> Subcategory: <span class="ml-5 "
                                                            x-text="research.category"></span></p>
                                                    
                                                    <p class=" text-gray-700 my-2"> Niche: <span class="ml-5 "
                                                            x-text="research.category"></span>
                                                    </p>
                                                    <p class=" text-gray-700 my-2"> Topic: <span class="ml-5 "
                                                            x-text="research.title"></span>
                                                    </p>
                                                    <p class=" text-gray-700 my-2"> Subtitle: <span class="ml-5 "
                                                            x-text="research.subtitle"></span></p>
                                                    <p class=" text-gray-700 my-2"> Price: <span class="ml-5 "
                                                            x-text="research.price"></span>
                                                    </p>
                                                    <p class=" text-gray-700 my-2"> Rating: <span class="ml-5 "
                                                            x-text="research.rating"></span>
                                                    </p>
                                                    <p class=" text-gray-700 my-2"> ISBN: <span class="ml-5 "
                                                            x-text="research.isbn"></span></p>
                                                    <p class=" text-gray-700 my-2"> Pages: <span class="ml-5 "
                                                            x-text="research.page_count"></span></p>
                                                </div>
                                                <div>
                                                    <h4 class="font-semibold mb-3">Description</h4>
                                                    <p class=" text-gray-700 my-2"x-text="research.description"></p>
                                                </div>
                                                <div>
                                                </div>
                                            </div>

                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="bg-white shadow-md border-b rounded p-3 my-2">
                            <p class="text-gray-300">welcome</p>
                            <div class="text-gray-300 py-3">
                                <h1 class="font-semibold text-md capitalize mb-5">No content Available</h1>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </section>
        </div>

        
        <div class="w-full" x-data="{ bookData: '' }">
            <h1 class=" capitalize text-md font-semibold mt-5"><i class="bx bx-book ml-1"></i> My Books</h1>
            <section class="">
                <?php if(isset($books)): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="bg-white shadow-md border-b relative rounded p-3 my-4  transition duration-300 ease-in-out cursor-pointer"
                            @click=" isOpen= true;  bookData = <?php echo \Illuminate\Support\Js::from($book)->toHtml() ?>">
                            <div class="flex justify-between">
                                <span
                                    class="text-gray-300 text-xs mb-3"><?php echo e($book->created_at->toFormattedDayDateString()); ?></span>
                                    <div class="text-xs ">
                                        <form id=""
                                            action="<?php echo e(route('books.destroy', ['book' => $book->id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="font-bold text-xs">Delete</button>
                                        </form>
                                    </div>
                            </div>

                            <div class="">
                                <div class="grid grid-cols-3 gap-4">
                                    <div class="overflow-hidden h-32 ">
                                        <img src="<?php echo e($book->image); ?>" alt="<?php echo e($book->title); ?>"
                                            class="w-[80%]  object-contain">
                                    </div>
                                    <div class="col-span-2">
                                        <h2 class=" font-bold text-sm text-gray-500"> <?php echo e($book->title); ?></h2>
                                        <p class="truncate text-gray-500 text-sm"><?php echo e($book->description); ?></p>
                                    </div>

                                </div>
                            </div>

                        </div>

                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

                            <div h-full>

                                
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-10 h-full">
                                    <div class="h-full shadow">
                                        <a :href="bookData.infolink" target="_blank"
                                            class=" first-letter:uppercase font-extrabold text-sm underline mt-2 inline "
                                            id="myTitle"><span x-text="bookData.title"></span></a><button
                                            onclick="toCopy(document.getElementById('myTitle')); "><i
                                                class='bx bx-copy ml-1 text-gray-300'></i></button>
                                        <div class="w-20 h-28 overflow-hidden shadow-sm">
                                            <img :src="bookData.image" alt="bookData.title"
                                                class="h-full  object-cover ">
                                        </div>
                                        <div class="grid grid-cols-2">
                                            <div class="grid grid-cols-2 col-span-1 gap-1 py-1">
                                                <div class=" text-xs capitalize">Rating</div>
                                                <div class=" text-xs" x-text="bookData.rating"></div>
                                                <div class=" text-xs capitalize">Publisher</div>
                                                <div class=" text-xs" x-text="bookData.author"></div>
                                                <div class=" text-xs capitalize">publissed Date</div>
                                                <div class=" text-xs" x-text="bookData.published_date"></div>
                                                <div class=" text-xs capitalize">Pages</div>
                                                <div class=" text-xs" x-text="bookData.pages"></div>
                                                <div class=" text-xs capitalize">Category</div>
                                                <div class=" text-xs" x-text="bookData.category"></div>
                                            </div>
                                        </div>
                                        <h2 class=" first-letter:uppercase font-extrabold text-sm  my-1 inline ">
                                            Description</h2>
                                        <button onclick="toCopy(document.getElementById('myDesc'))"><i
                                                class='bx bx-copy ml-1 text-gray-300'></i></button>
                                        <div class="h-40 overflow-auto">
                                            <p class=" first-letter:uppercase text-xs " id="myDesc"
                                                x-text="bookData.description"></p>
                                        </div>
                                    </div>
                                    <div class="overflow-hidden px-10 overflow-y-auto shadow">
                                        <div w-[80%] h-[100px]>
                                            <img :src="bookData.image" alt="bookData.title"
                                                class="w-[80%]  object-contain shadow-md transform duration-700  hover:opacity-90 ">
                                        </div>
                                    </div>
                                </div>
                            </div>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="bg-white shadow-md border-b rounded p-3 my-2">
                            <p class="text-gray-300">welcome</p>
                            <div class="text-gray-300 py-3">
                                <h1 class="font-semibold text-md capitalize mb-5">No content Available</h1>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </section>
        </div>

        
        <div class="w-full">
            <h1 class=" capitalize text-md font-semibold mt-5"><i class="bx bx-book ml-1"></i> My Content Idea</h1>
            <section class="">
                <?php if(isset($courses)): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e(route('courses.edit', ['course' => $course->id])); ?>" >
                            <div
                                class="bg-white shadow-md border-b relative rounded p-3 my-4  transition duration-300 ease-in-out">
                                <div class="flex justify-between">
                                    <span
                                        class="text-gray-300 text-xs"><?php echo e($course->created_at->toFormattedDayDateString()); ?></span>
                                    <div class="text-xs">
                                        Edit
                                    </div>

                                </div>

                                <div class="">
                                    <h2 class="mb-3 font-bold text-sm text-gray-500"> <?php echo e($course->title); ?></h2>
                                    <div class="">
                                        <div class="overflow-hidden h-24 line-clamp-3">
                                            <?php $__currentLoopData = $course->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p class="truncate text-gray-500 text-sm"><?php echo e($loop->iteration); ?>.
                                                    <?php echo e($lesson->title); ?></p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="bg-white shadow-md border-b rounded p-3 my-2">
                            <p class="text-gray-300">welcome</p>
                            <div class="text-gray-300 py-3">
                                <h1 class="font-semibold text-md capitalize mb-5">No content Available</h1>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </section>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.notification','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('notification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <script>
        // for coping text
        function toCopy(copyDiv) {
            var range = document.createRange();
            range.selectNode(copyDiv);
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);
            document.execCommand("copy");
            alert("copied!" );
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\AI-Course-shop-master\resources\views/users/content-planner.blade.php ENDPATH**/ ?>