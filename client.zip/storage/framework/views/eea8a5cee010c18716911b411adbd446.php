<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php echo seo()->render([
        'title' => $course->title,
        'description' => $course->description,
        'image' => asset($course->course_image),
        'type' => 'article',
        'url' => route('courses.share', ['courseId' => $course->id, 'course_slug' => $course->slug]),
    ]); ?>
    <?php if(session('message')): ?>
        <div class="alert alert-success" role="alert"><?php echo e(session('message')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
    <?php endif; ?>


    <div class="grid grid-cols-1 md:grid-cols-3 w-full  md:w-[80%] mx-auto">
        <div class="col-span-1 bg-gray-50 px-10  text-gray-700 py-10 grid grid-cols-2 gap-2">
            <div class=" object-cover overflow-hidden border-r-4 border-b-4 h-40">
                <img src="<?php echo e(asset($course->course_image)); ?>" alt="" class="w-full  h-full">
            </div>
            <div>
                <h1 class="text-xl font-bold mb-3 capitalize"><?php echo e($course->title); ?></h1>
                <p class="text-sm  my-3 capitalize line-clamp-3 w-36"><?php echo e($course->description); ?></p>

                <div class="text-yellow-500">
                    <i class='bx bxs-star '></i>
                    <i class='bx bxs-star '></i>
                    <i class='bx bxs-star '></i>
                    <i class='bx bxs-star-half'></i>
                    <i class='bx bx-star '></i>
                </div>
            </div>
        </div>
        <div class="col-span-2">

            <div class="mt-10 bg-gray-50 px-0 pt-8 lg:mt-0 px-10">
                <p class="text-xl font-medium">Subscribe To Grab The Course</p>
                <p class="text-gray-400">Enjoy the move!!</p>
                <div class="">
                    <?php if($course->courseSettings->checkout_option === 'email'): ?>
                        <div class="py-10">
                            <form action="<?php echo e(route('subscribe.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <label for="email" class="mt-4 mb-2 block text-sm font-medium">Email</label>
                                <div class="relative">
                                    <input type="text" value="<?php echo e($course->id); ?>" name="courseId" hidden>
                                    <input type="text" value="<?php echo e($list_id); ?>" name="list_id" hidden>
                                    <input type="hidden" name="is_admin" value="user">
                                    <input type="text" id="name" name="name"
                                        class="w-full rounded-md border border-gray-200 px-0 py-3 pl-3 text-sm shadow-sm outline-none focus:z-10 focus:border-blue-500 focus:ring-blue-500"
                                        placeholder="smith" name="name" />
                                    <input type="text" id="email" name="email"
                                        class="w-full rounded-md border border-gray-200 px-0 py-3 mt-3 pl-3 text-sm shadow-sm outline-none focus:z-10 focus:border-blue-500 focus:ring-blue-500"
                                        placeholder="your.email@gmail.com" name="email" />
                                </div>
                                <button
                                    class="mt-4 mb-8 w-full rounded-md bg-gray-900 px-6 py-3 font-medium text-white" type="submit">Subscribe</button>
                            </form>
                        </div>
                    <?php elseif($course->courseSettings->checkout_option === 'payment'): ?>
                        <div class="flex-center position-ref full-height">

                            <div class="content">
                                <form action="<?php echo e(route('subscribe.paymentData')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <label for="email" class="mt-4 mb-2 block text-sm font-medium">Email</label>
                                    <div class="relative">
                                        <input type="hidden" name="is_admin" value="user">
                                        <input type="text" id="name" name="name"
                                            class="w-full rounded-md border border-gray-200 px-0 py-3 pl-3 text-sm shadow-sm outline-none focus:z-10 focus:border-blue-500 focus:ring-blue-500"
                                            placeholder="smith" name="name"
                                            value="<?php echo e(auth()->check() ? auth()->user()->name : ''); ?>" />
                                        <input type="text" id="email" name="email"
                                            class="w-full rounded-md border border-gray-200 px-0 py-3 mt-3 pl-3 text-sm shadow-sm outline-none focus:z-10 focus:border-blue-500 focus:ring-blue-500"
                                            placeholder="your.email@gmail.com" name="email"
                                            value="<?php echo e(auth()->check() ? auth()->user()->email : ''); ?>" />
                                    </div>
                                    <button
                                        class="mt-4 mb-8 w-full rounded-md bg-gray-900 px-6 py-3 font-medium text-white">save</button>
                                </form>
                            </div>
                            <div class="">
                                <table border="0" cellpadding="10" cellspacing="0" align="center">
                                    <tr>
                                        <td align="center"></td>
                                    </tr>
                                    <tr>
                                        <td align="center">
                                            <a href="https://www.paypal.com/in/webapps/mpp/paypal-popup"
                                                title="How PayPal Works"
                                                onclick="javascript:window.open('https://www.paypal.com/in/webapps/mpp/paypal-popup','WIPaypal','toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=1060, height=700'); return false;"><img
                                                    src="https://www.paypalobjects.com/webstatic/mktg/Logo/pp-logo-200px.png"
                                                    border="0" alt="PayPal Logo"></a>
                                        </td>
                                    </tr>
                                </table>
                            </div>


                            <form action="<?php echo e(route('payment')); ?>" method="get">
                                <?php echo csrf_field(); ?>
                                <div class="flex-shrink w-full inline-block relative">
                                    <input type="text" name="title" value="<?php echo e($course->title); ?>" hidden>
                                    <input type="text" name="price" value="<?php echo e($course->price); ?>" hidden>
                                    <input type="text" name="courseId" value="<?php echo e($course->id); ?>" hidden>

                                </div>
                                <button type="submit"
                                    class="mt-4 mb-8 w-full rounded-md bg-gray-900 px-6 py-3 font-medium text-white">
                                    Pay $<?php echo e($course->price); ?> from Paypal
                                </button>
                            </form>

                        </div>
                    <?php else: ?>
                        <?php
                            
                            $socialLinks = Share::page(route('courses.share', ['courseId' => $course->id, 'course_slug' => $course->slug]), 'Share title')
                                ->facebook()
                                ->twitter()
                                ->linkedin('Extra linkedin summary can be passed here')
                                ->whatsapp()
                                ->getRawLinks();
                        ?>
                        <div class="flex justify-around  mt-4 mb-8 ">
                            <?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform => $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($platform == 'facebook'): ?>
                                    <a href="<?php echo e($link); ?>" class="social-button" id=""
                                        data-platform="facebook" title="" rel="" target="_blank">
                                        <img src="<?php echo e(asset('images/facebook_media.png')); ?>" alt=""
                                            class="w-8 h-8">
                                    </a>
                                <?php elseif($platform == 'twitter'): ?>
                                    <a href="<?php echo e($link); ?>" class="social-button" id=""
                                        data-platform="twitter" title="" rel="" target="_blank">
                                        <img src="<?php echo e(asset('images/twitter_blue.png')); ?>" alt=""
                                            class="w-8 h-8">
                                    </a>
                                <?php elseif($platform == 'linkedin'): ?>
                                    <a href="<?php echo e($link); ?>" class="social-button" id=""
                                        data-platform="linkedin" title="" rel="" target="_blank">
                                        <img src="<?php echo e(asset('images/linkedin.png')); ?>" alt=""
                                            class="w-8 h-8">
                                    </a>
                                <?php elseif($platform == 'whatsapp'): ?>
                                    <a href="<?php echo e($link); ?>" class="social-button" id=""
                                        data-platform="whatsapp" title="" rel="" target="_blank">
                                        <img src="<?php echo e(asset('images/whatsapp.png')); ?>" alt=""
                                            class="w-8 h-8">
                                    </a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                        <button type="button"
                            class="mt-4 mb-8 w-full rounded-md bg-blue-600 px-6 py-3 font-medium text-white">
                        </button>
                    <?php endif; ?>
                </div>
            </div>

        </div>



        <script src="https://js.stripe.com/v3/"></script>



        <script>
            // Declare childWindow in a broader scope
            var childWindow;

            document.querySelectorAll('.social-button').forEach(function(button) {
                button.addEventListener('click', function(event) {
                    event.preventDefault(); // Prevent the default link behavior

                    // Get the platform from the data-platform attribute
                    var platform = button.getAttribute('data-platform');
                    var courseSlug = '<?php echo e($course->slug); ?>';
                    var courseId = '<?php echo e($course->id); ?>';

                    // Make an AJAX request to track the share event (similar to your previous code)
                    fetch('<?php echo e(route('track-share-event')); ?>', {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({
                                platform: platform,
                                course_slug: courseSlug,
                                courseId: courseId,
                                // Include other relevant data as needed
                            }),

                        })
                        .then(response => {
                            console.log('Share event data sent:', response);

                            childWindow = window.open(button.getAttribute('href'), '_blank');

                        })
                        .catch(error => {
                            console.error(error);
                        });
                });
            });

            let timeoutId; // Store the timeout ID

            document.onvisibilitychange = function() {
                if (document.hidden) {
                    console.log('User is now away from the page');

                    timeoutId = setTimeout(function() {
                        if (childWindow && !childWindow.closed) {
                            childWindow.close();
                        }

                        window.location.href =
                            '<?php echo e(route('courses.share', ['courseId' => $course->id, 'course_slug' => $course->slug])); ?>';
                    }, 10000); // 10 minutes
                } else {
                    console.log('User is back to the page');


                }
            };
        </script>



         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\AI-Course-shop-master\resources\views/pages/courses/subscribe.blade.php ENDPATH**/ ?>