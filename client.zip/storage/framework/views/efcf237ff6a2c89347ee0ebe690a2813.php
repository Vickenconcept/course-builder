<div>
    <?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['modalData','title']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['modalData','title']); ?>
<?php foreach (array_filter((['modalData','title']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div 

 class="flex items-center justify-center absolute top-0 left-0 mx-auto w-full h-full bg-gray-400 bg-opacity-20 z-10"
    x-show="isOpen" style="display: none;" >
    <div
        class="bg-white w-[90%] shadow-sm border rounded overflow-auto h-[70%] my-auto pb-6 transition-all relative duration-700">
        <div>
            <button type="button" class=" font-bold px-4 pt-3" @click="isOpen = false">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
            </button>
            
            <?php if(!isset($generatedResponse)): ?>
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-button','data' => ['class' => 'text','wire:click' => 'aiCourseGenerator','wire:loading.attr' => 'disabled','type' => 'submit','wire:target' => 'aiCourseGenerator']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text','wire:click' => 'aiCourseGenerator','wire:loading.attr' => 'disabled','type' => 'submit','wire:target' => 'aiCourseGenerator']); ?>
                    Generate
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-button','data' => ['class' => 'text','wire:click' => 'regenerate','wire:loading.attr' => 'disabled','type' => 'submit','wire:target' => 'aiCourseGenerator']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text','wire:click' => 'regenerate','wire:loading.attr' => 'disabled','type' => 'submit','wire:target' => 'aiCourseGenerator']); ?>
                    Regenerate
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="p-5 overflow-y-auto">
            <?php if(isset($generatedResponse)): ?>
                <div class="flex justify-end">
                    <button class="  bg-yellow-700 text-white rounded-lg px-2 py-1  shadow-sm text-xs"
                        @click="isOpen = false" wire:click="sendModalResponse">Add Content to
                        Textarea
                    </button>
                    <button onclick="toCopy(document.getElementById('title_<?php echo e($uniqueId); ?>'))">
                        <i class="bx bx-copy ml-2 text-gray-700"></i>
                    </button>
                </div>
                
                <div id="title_<?php echo e($uniqueId); ?>">
                    <?php echo nl2br($generatedResponse); ?>

                </div>
            <?php endif; ?>

        </div>
    </div>
</div>
<script>
    // for coping text
    function toCopy(copyDiv) {
        var range = document.createRange();
        range.selectNode(copyDiv);
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);
        document.execCommand("copy");
        alert("copied!" );
    }
</script>

</div><?php /**PATH C:\wamp64\www\AI-Course-shop-master\resources\views/livewire/modal.blade.php ENDPATH**/ ?>