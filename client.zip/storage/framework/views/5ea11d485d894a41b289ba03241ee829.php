<?php
    $type = null;
    $msg = null;

    if (session()->has('success')) {
    $type = 'success';
    $msg = session('success');
    }

    if (session()->has('message') || session()->has('status')) {
    $type = 'info';
    $msg = session('status') ?? session('message');
    }

    if (session()->has('error')) {
    $type = 'error';
    $msg = session('error');
    }
?>


<?php if(session()->has('success')): ?>
<div x-data="notification">
    <div x-data="{message: notify(`<?php echo e($msg); ?>`) }"></div>
</div>
<?php endif; ?><?php /**PATH C:\wamp64\www\AI-Course-shop-master\resources\views/components/notification.blade.php ENDPATH**/ ?>