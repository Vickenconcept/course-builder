<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.notification','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('notification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <div class="p-2 md:px-10">

        <div class="flex flex-wrap my-5 -mx-2">
            <div class="w-full lg:w-1/3 p-2">
                <div class="flex items-center flex-row w-full bg-gradient-to-r  bg-yellow-900 rounded-md px-3 py-8">
                    
                    <div class="flex flex-col justify-around flex-grow ml-5 text-white">
                        <div class="text-xs whitespace-nowrap">
                            Total User
                        </div>
                        <div class="">
                            <?php echo e($userStats->total_users); ?>

                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="w-full md:w-1/2 lg:w-1/3 p-2">
                <div class="flex items-center flex-row w-full bg-gradient-to-r  bg-yellow-500 rounded-md px-3 py-8">
                    
                    <div class="flex flex-col justify-around flex-grow ml-5 text-white">
                        <div class="text-xs whitespace-nowrap">
                            Verified Users
                        </div>
                        <div class="">
                       <?php echo e($userStats->verified_users); ?>

                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="w-full md:w-1/2 lg:w-1/3 p-2">
                <div class="flex items-center flex-row w-full bg-gradient-to-r  bg-yellow-900 rounded-md px-3 py-8">
                    
                    <div class="flex flex-col justify-around flex-grow ml-5 text-white">
                        <div class="text-xs whitespace-nowrap">
                            Total Visitor
                        </div>
                        <div class="">
                            0
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

        <section class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div class="w-full">
                <section class="text-xs ">
                    <div class="bg-white shadow-md border-b rounded p-3 my-1">
                        <p class="text-gray-300">3 mins ago</p>

                    
                    </div>
                </section>
            </div>

            <div class="w-full">
                <section class="text-xs ">
                    <div class="bg-white shadow-md border-b rounded p-3 my-1">
                        <p class="text-gray-300">3 mins ago</p>

                    
                    </div>
                </section>
            </div>
        </section>

        <section class="mt-16 overflow-auto">
            <!-- <h1 class="font-bold text-blue-900 text-sm">Total Users <span class="bg-blue-200 rounded-full p-0.5 text-xs text-blue-50"><?php echo e($users->count()); ?></span></h1> -->
            <table class=" w-full mt-5  ">
                <thead>

                    <tr class="text-left border-b-2 shadow bg-white ">
                        <th scope="col" class="text-blue-900  font-semibold firstletter:uppercase text-sm pt-10 pl-10  ">S/N</th>
                        <th scope="col" class="text-blue-900  font-semibold firstletter:uppercase text-sm pt-10 ">Name</th>
                        <th scope="col" class="text-blue-900  font-semibold firstletter:uppercase text-sm pt-10 ">Email</th>
                        <th scope="col" class="text-blue-900  font-semibold firstletter:uppercase text-sm pt-10 ">Date</th>
                        <th scope="col" class="text-blue-900  font-semibold firstletter:uppercase text-sm pt-10 "></th>
                        <th scope="col" class="text-blue-900  font-semibold firstletter:uppercase text-sm pt-10 "></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-left border-b-2 shadow hover:bg-white transition duration-300 rounded-lg">
                        <td class="text-blue-900 whitespace-nowrap text-xs py-2 pl-10  form-semibold"><?php echo e($loop->iteration); ?></td>
                        <td class="text-blue-900 whitespace-nowrap text-xs py-2 ">
                             
                             <?php echo e($user->name); ?></td>
                        <td class="text-blue-900 whitespace-nowrap text-xs py-2"><?php echo e($user->email); ?></td>
                        <td class="text-blue-900 whitespace-nowrap text-xs py-2"><?php echo e($user->created_at); ?></td>
                        <td class="text-blue-900 whitespace-nowrap text-xs py-2"><?php echo e($user->is_admin); ?></td>
                        <td class="text-blue-900 whitespace-nowrap text-xs py-2 pr-10">
                            <form action="<?php echo e(route('dashboard.update', ['dashboard' => $user->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <label for="userType">Update to Admin:</label>
                                

                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Update <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
        </section>

        

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\AI-Course-shop-master\resources\views/dashboard.blade.php ENDPATH**/ ?>