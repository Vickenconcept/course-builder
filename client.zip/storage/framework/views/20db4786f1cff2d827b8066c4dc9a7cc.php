<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['lesson']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['lesson']); ?>
<?php foreach (array_filter((['lesson']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="  mt-0.5 ">

    <div x-data="{ open: false, isOpen: false }" class="">
        
        <div class="relative ">
            <div class="border px-2  shadow text-gray-500 font-semibold flex items-center justify-between">
                <div class="pl-2 flex flex-grow">
                    
                    <form action="<?php echo e(route('lesson.update', ['lesson' => $lesson->id ])); ?>" method="POST" class="w-full">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="text text-2xl font-bold text-gray-700 uppercase"
                            class="w-[70%]  border-transparent  p-3 placholder-gray-700 placeholder:font-bold placeholder:uppercase"
                            value="<?php echo e($lesson->title); ?>" name="lesson">
                    </form>
                </div>

                <button @click="open = !open">
                    <svg class="w-6 h-6 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                    </svg>
                </button>
            </div>
            <div x-show="open ? open : childIsOpen"
                class=" bg-gray-50 border rounded transition duration-700 ease-in-out ">
                <div class="flex justify-end">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown','data' => ['align' => 'right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => 'right']); ?>
                         <?php $__env->slot('trigger', null, []); ?> 
                            <button
                                class="  bg-yellow-700 border text-white rounded-lg px-2 py-1  shadow-sm text-xs text-right">
                                <span class=""> AI</span>
                            </button>
                         <?php $__env->endSlot(); ?>
                         <?php $__env->slot('content', null, []); ?> 
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['class' => 'cursor-pointer','@click' => 'isOpen = true ; ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'cursor-pointer','@click' => 'isOpen = true ; ']); ?>
                                <button>
                                    write an intro summary for this module based on this title
                                </button>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                         <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('modal', ['title' => $lesson->title,'lesson' => $lesson])->html();
} elseif ($_instance->childHasBeenRendered('dZtS6gn')) {
    $componentId = $_instance->getRenderedChildComponentId('dZtS6gn');
    $componentTag = $_instance->getRenderedChildComponentTagName('dZtS6gn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dZtS6gn');
} else {
    $response = \Livewire\Livewire::mount('modal', ['title' => $lesson->title,'lesson' => $lesson]);
    $html = $response->html();
    $_instance->logRenderedChild('dZtS6gn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <div id="here">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('text-editor', ['lesson' => $lesson])->html();
} elseif ($_instance->childHasBeenRendered('RMs26dj')) {
    $componentId = $_instance->getRenderedChildComponentId('RMs26dj');
    $componentTag = $_instance->getRenderedChildComponentTagName('RMs26dj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RMs26dj');
} else {
    $response = \Livewire\Livewire::mount('text-editor', ['lesson' => $lesson]);
    $html = $response->html();
    $_instance->logRenderedChild('RMs26dj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
                <div class="flex justify-end p-1">
                    <form action="<?php echo e(route('lesson.destroy', ['lesson' => $lesson->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit"
                            class="py-1 px-4 rounded-full bg-transparent border mx-3 text-red-500 border-red-500">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                            </svg>
                        </button>
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>


<script>
    // function updateDiv() {
    //     $("#here").load(window.location.href + " #here");
    //     console.log('i am clicked');
    // }
</script>
<?php /**PATH C:\wamp64\www\AI-Course-shop-master\resources\views/components/course-lesson.blade.php ENDPATH**/ ?>