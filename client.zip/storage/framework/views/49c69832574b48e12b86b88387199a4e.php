<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div x-data="{ openShare: false }">
        
        <?php echo seo()->render([
            'title' => $course->title,
            'description' => $course->description,
            'image' => asset($course->course_image),
            'type' => 'article',
            'url' => route('courses.share', ['courseId' => $course->id, 'course_slug' => $course->slug]),
        ]); ?>

        <div class="w-full flex justify-center items-center pt-10">
            <div id="flipbook" class="sj-book">
                
                <div
                    class="hard front-cover bg-gray-300 rounded-tr-lg rounded-br-lg text-gray-700 text-center border border-gray-700 ">
                    <div class="bg-cover bg-no-repeat w-full bg-center h-full"
                        style="background-image: url('<?php echo e(asset($course->course_image)); ?>');"></div>
                </div>
                <div class="hard  bg-gray-500 rounded-tl-lg rounded-bl-lg "></div>

                <section class="  pt-4 capitalize bg-white px-5   even">
                    <h1 class="font-bold text-xl my-5 capitalize"> Title: <?php echo e($course->title); ?></h1>
                    <h4 class="font-semibold my-5 text-md"> Introduce:</h4>
                    <p class="  text-xs  text-justify my-3">
                        <?php echo e($course->description); ?>

                    </p>

                </section>
                <section class="  pt-4 capitalize bg-white px-5   even">
                    <h3 class="font-semibold my-5">Outline:</h3>
                    <ol class="text-xs">
                        <?php $__currentLoopData = $course->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="py-2"> <?php echo e($loop->iteration); ?>. <?php echo e($lesson->title); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </section>
                <?php if($isSubscribed): ?>
                    <?php $__currentLoopData = $course->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <section class=" pt-4 bg-white px-5  even">
                            <h3 class="font-semibold capitalize pt-4 text-sm"><?php echo e($loop->iteration); ?>.
                                <?php echo e($lesson->title); ?>

                            </h3>
                            <p class="text-xs"><?php echo $lesson->content; ?></p>
                        </section>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php elseif($course->courseSettings->checkout_option === 'share' && $hasIpAddressAccess): ?>
                    
                    <?php $__currentLoopData = $course->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <section class=" pt-4 bg-white px-5  even">
                            <h3 class="font-semibold capitalize pt-4 text-sm"><?php echo e($loop->iteration); ?>.
                                <?php echo e($lesson->title); ?>

                            </h3>
                            <p class="text-xs"><?php echo $lesson->content; ?></p>
                        </section>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php $__currentLoopData = $course->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($loop->iteration <= $freeCourse): ?>
                            <section class=" pt-4 bg-white px-5  even">
                                <h3 class="font-semibold capitalize pt-4 text-sm"><?php echo e($loop->iteration); ?>.
                                    <?php echo e($lesson->title); ?>

                                </h3>
                                <p class="text-xs"><?php echo $lesson->content; ?></p>
                            </section>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if(count($course->lessons) > $freeCourse): ?>
                        <!-- Add a section or button to show all lessons -->
                        <section class=" pt-4 flex justify-center items-center bg-white px-5 even">
                            <div class=" text-center">
                                <h1 class="text-xl font-bold my-5"> "Unlock a World of Knowledge – Click Here to Explore
                                    More!"</h1>
                                
                                <a href="<?php echo e(route('subscribe.show', ['subscribe' => $course->id])); ?>">
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-button','data' => ['id' => 'showAllLessonsButton','class' => ' inline-flex animate-pulse']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'showAllLessonsButton','class' => ' inline-flex animate-pulse']); ?>
                                        Click to read more <i class='bx bx-chevrons-right  animate-ping'></i>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                                </a>
                            </div>
                        </section>
                    <?php endif; ?>
                <?php endif; ?>
                <section
                    class="hard bg-white flex  items-center  justify-center  text-white rounded-tr-lg rounded-br-lg even">
                </section>
                <section
                    class="hard bg-gray-500 flex j items-center  justify-center  text-white rounded-tr-lg rounded-br-lg even">
                </section>
                
                <div class=" hard back-cover bg-gray-300  text-gray-700 text-center rounded-tr-lg rounded-bl-lg ">
                    
                </div>
            </div>
        </div>
        <div class="  text-center" id="controls">
            <button id="previousButton"
                class="bg-yellow-500 text-white shadow-sm hover: rounded-full py-1 px-2 "><i
                    class='bx bx-chevron-left text-2xl'></i></button>
            <button id="nextButton"
                class="bg-yellow-500 text-white shadow-sm hover: rounded-full py-1 px-2 ronded"><i
                    class='bx bx-chevron-right text-2xl'></i></button>
        </div>

        


        
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\AI-Course-shop-master\resources\views/pages/courses/embed_show.blade.php ENDPATH**/ ?>