<?php return array (
  'content-generator' => 'App\\Http\\Livewire\\ContentGenerator',
  'course' => 'App\\Http\\Livewire\\Course',
  'course-content' => 'App\\Http\\Livewire\\CourseContent',
  'lesson-architect' => 'App\\Http\\Livewire\\LessonArchitect',
  'modal' => 'App\\Http\\Livewire\\Modal',
  'text-editor' => 'App\\Http\\Livewire\\TextEditor',
);